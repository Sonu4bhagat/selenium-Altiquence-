package locators;

import org.openqa.selenium.By;

public class NavigationLocators {

    public static final By OPEN_BTN = By.xpath("//h5[contains(text(), 'bots022-UW-testk6')]/ancestor::div[contains(@class, 'wallet-card')]//button[contains(text(), 'Open')]");
    public static final By SERVICES_TAB = By.xpath("//span[contains (text(), 'Services')]");
    public static final By VIEW_DETAIL_BTN = By.xpath("//h5[contains(text(), 'RCS')]/ancestor::div[contains(@class, 'card') and contains(@class, 'service-cards')]//button[contains(text(), 'View Details')]");
    public static final By SSO_ICON = By.xpath("//td[contains(text(), 'RCSHELL50')]/parent::tr//button[@mattooltip='SSO redirection']");
    public static final By CONTROL_CENTER_TAB = By.xpath("//span[contains (text(), 'Control Center')]");
    public static final By ASSISTANT_TAB = By.xpath("//span[contains (text(), ' Assistants ')]");
}
