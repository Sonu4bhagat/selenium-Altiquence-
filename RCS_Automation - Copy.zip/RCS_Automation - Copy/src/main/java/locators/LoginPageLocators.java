package locators;

import org.openqa.selenium.By;

public class LoginPageLocators {
    public static final By EMAIL_INPUT = By.id("loginEmail");
    public static final By PASSWORD_INPUT = By.id("cst_login_pwd");
    public static final By LOGIN_BUTTON = By.xpath("//button[@value='Login']");
    public static final By OTP_INPUT_FIELDS = By.xpath("//div[@id='verify_otp_sec']//input[@type='text']");
    public static final By VERIFY_BUTTON = By.xpath("//span[contains(text(), 'Verify')]");

    // Dashboard checks
    public static final By SUPER_ADMIN_DASHBOARD = By.xpath("//h5[contains(text(),'Welcome')]");
    public static final By ENTERPRISE_DASHBOARD = By.xpath("//h1[@class='cst_welcome_text']");
    public static final By RESELLER_DASHBOARD = By.xpath("//h1[@class='cst_welcome_text']");
}
