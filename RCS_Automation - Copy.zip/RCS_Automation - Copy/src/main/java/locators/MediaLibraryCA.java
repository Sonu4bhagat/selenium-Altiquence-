package locators;

import org.openqa.selenium.By;

public class MediaLibraryCA {
    public static final By MEDIA_LIBRARY = By.xpath("//span[contains (text(),'Media Library')]");
}
