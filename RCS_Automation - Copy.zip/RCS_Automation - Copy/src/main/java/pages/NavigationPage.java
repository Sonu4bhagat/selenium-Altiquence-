package pages;

import locators.MediaLibraryLocators;
import locators.NavigationLocators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.Set;

public class NavigationPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public NavigationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void clickOpenButton() {
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.OPEN_BTN)).click();
        System.out.println("Clicked on 'Open' button.");
    }

    public void clickServicesTab() {
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.SERVICES_TAB)).click();
        System.out.println("Clicked on 'Services' tab.");
    }

    public void clickViewDetails() {
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.VIEW_DETAIL_BTN)).click();
        System.out.println("Clicked on 'View Details' button.");
    }

    public void clickSSORedirectionIcon() {
        String mainWindow = driver.getWindowHandle();
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.SSO_ICON)).click();
        System.out.println("Clicked on 'SSO Redirection' icon.");

        // Wait and switch to new tab
        Set<String> handles;
        int attempts = 0;
        do {
            handles = driver.getWindowHandles();
            attempts++;
        } while (handles.size() == 1 && attempts < 10);

        for (String handle : handles) {
            if (!handle.equals(mainWindow)) {
                driver.switchTo().window(handle);
                System.out.println("Switched to new SSO tab.");
                break;
            }
        }
    }

    public void clickControlCenter() {
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.CONTROL_CENTER_TAB)).click();
        System.out.println("Clicked on 'Control Center' tab.");
    }

    public void clickAssistantTab() {
        wait.until(ExpectedConditions.elementToBeClickable(NavigationLocators.ASSISTANT_TAB)).click();
        System.out.println("Clicked on 'Assistant' tab.");
    }

    public void navigateToAssistantList() {
        clickOpenButton();
        clickServicesTab();
        clickViewDetails();
        clickSSORedirectionIcon();
        clickControlCenter();
        clickAssistantTab();
        System.out.println("Navigation to Assistant list completed.");
    }
    public void navigateToMediaLibrary() {
        clickOpenButton();
        clickServicesTab();
        clickViewDetails();
        clickSSORedirectionIcon();
        wait.until(ExpectedConditions.elementToBeClickable(MediaLibraryLocators.MEDIA_LIBRARY_TAB)).click();
        System.out.println("Navigation to Media Library page");
    }
}
