package pages;

import locators.MediaLibraryLocators;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MediaLibraryPage {
    WebDriver driver;

    public MediaLibraryPage(WebDriver driver) {
        this.driver = driver;
    }

    public void navigateToAllFiles() {
        driver.findElement(MediaLibraryLocators.MEDIA_LIBRARY_TAB).click();
        driver.findElement(MediaLibraryLocators.ALL_FILES_TAB).click();
    }

    public void clickUploadMedia() {
        driver.findElement(MediaLibraryLocators.UPLOAD_MEDIA_BUTTON).click();
    }

    public void uploadMediaFile(String fileName) {
        WebElement uploadField = driver.findElement(MediaLibraryLocators.FILE_INPUT_IN_POPUP);
        String fullPath = System.getProperty("user.dir") + "\\src\\main\\resources\\media\\" + fileName;
        uploadField.sendKeys(fullPath);
    }

    public String getFirstMediaFileName() {
        return driver.findElement(MediaLibraryLocators.FIRST_MEDIA_NAME).getText().trim();
    }
}
