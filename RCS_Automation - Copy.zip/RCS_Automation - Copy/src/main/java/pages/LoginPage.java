package pages;

import locators.LoginPageLocators;
import enums.UserRole;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import utils.ConfigReader;

import java.time.Duration;
import java.util.List;

public class LoginPage {
    WebDriver driver;
    WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void enterUsername(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(LoginPageLocators.EMAIL_INPUT)).sendKeys(email);
    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(LoginPageLocators.PASSWORD_INPUT)).sendKeys(password);
    }

    public void clickLoginButton() {
        wait.until(ExpectedConditions.elementToBeClickable(LoginPageLocators.LOGIN_BUTTON)).click();
    }

    public void enterOTP(String otp) {
        List<WebElement> otpFields = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(LoginPageLocators.OTP_INPUT_FIELDS));
        for (int i = 0; i < otp.length(); i++) {
            WebElement otpField = otpFields.get(i);
            otpField.clear();
            otpField.sendKeys(String.valueOf(otp.charAt(i)));
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void clickVerifyButton() {
        wait.until(ExpectedConditions.elementToBeClickable(LoginPageLocators.VERIFY_BUTTON)).click();
    }

    public boolean isDashboardLoaded(UserRole role) {
        try {
            switch (role) {
                case SUPERADMIN:
                    return wait.until(ExpectedConditions.presenceOfElementLocated(LoginPageLocators.SUPER_ADMIN_DASHBOARD)).isDisplayed();
                case ENTERPRISE:
                    return wait.until(ExpectedConditions.presenceOfElementLocated(LoginPageLocators.ENTERPRISE_DASHBOARD)).isDisplayed();
                case RESELLER:
                    return wait.until(ExpectedConditions.presenceOfElementLocated(LoginPageLocators.RESELLER_DASHBOARD)).isDisplayed();
                default:
                    return false;
            }
        } catch (TimeoutException e) {
            return false;
        }
    }

    public void loginWithEnterpriseCredentials() {
        String username = ConfigReader.get("enterprise.email");
        String password = ConfigReader.get("enterprise.password");
        String otp = "112233"; // If static/test OTP is allowed

        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        enterOTP(otp);
        clickVerifyButton();

        if (!isDashboardLoaded(UserRole.ENTERPRISE)) {
            throw new IllegalStateException("Enterprise dashboard did not load.");
        }
    }
}
