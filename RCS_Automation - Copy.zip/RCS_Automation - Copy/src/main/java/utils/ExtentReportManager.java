package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager {

    private static ExtentReports extent;
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public static ExtentReports getExtentReports() {
        if (extent == null) {
            // Create Spark Reporter (HTML file)
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter("test-output/ExtentReport.html");

            // Manual configuration (instead of loading XML)
            sparkReporter.config().setDocumentTitle("RCS Automation Report");
            sparkReporter.config().setReportName("RCS Assistant Module Test Report");
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");

            // Attach reporter to ExtentReports instance
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);

            // System/environment info (optional)
            extent.setSystemInfo("Project", "RCS Automation");
            extent.setSystemInfo("Tester", "Your Name");
            extent.setSystemInfo("Environment", "Staging");
            extent.setSystemInfo("OS", System.getProperty("os.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        }
        return extent;
    }

    public static ExtentTest createTest(String testName) {
        ExtentTest extentTest = getExtentReports().createTest(testName);
        test.set(extentTest);
        return extentTest;
    }

    public static ExtentTest getTest() {
        return test.get();
    }

    public static void removeTest() {
        test.remove();
    }
}
