package utils;

import config.ConfigReader;
import enums.UserRole;

public class UserCredentialProvider {

    public static String getEmail(UserRole role) {
        switch (role) {
            case SUPERADMIN:
                return ConfigReader.getProperty("superadmin.email");
            case ENTERPRISE:
                return ConfigReader.getProperty("enterprise.email");
            case RESELLER:
                return ConfigReader.getProperty("reseller.email");
            default:
                throw new IllegalArgumentException("Unknown user role");
        }
    }

    public static String getPassword(UserRole role) {
        switch (role) {
            case SUPERADMIN:
                return ConfigReader.getProperty("superadmin.password");
            case ENTERPRISE:
                return ConfigReader.getProperty("enterprise.password");
            case RESELLER:
                return ConfigReader.getProperty("reseller.password");
            default:
                throw new IllegalArgumentException("Unknown user role");
        }
    }
}
