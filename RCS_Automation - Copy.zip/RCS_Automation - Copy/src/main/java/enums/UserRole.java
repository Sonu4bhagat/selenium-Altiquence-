package enums;

public enum UserRole {
    SUPERADMIN,
    ENTERPRISE,
    RESELLER
}