package tests;

import base.BaseTest;
import enums.UserRole;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import utils.UserCredentialProvider;

public class LoginTest extends BaseTest {

    @DataProvider(name = "userRoles")
    public Object[][] userRoles() {
        return new Object[][]{
                {UserRole.SUPERADMIN},
                {UserRole.ENTERPRISE},
                {UserRole.RESELLER}
        };
    }

    @Test(dataProvider = "userRoles")
    public void loginTest(UserRole role) {
        LoginPage login = new LoginPage(driver);

        String email = UserCredentialProvider.getEmail(role);
        String password = UserCredentialProvider.getPassword(role);

        login.enterUsername(email);
        login.enterPassword(password);
        login.clickLoginButton();
        login.enterOTP("112233");
        login.clickVerifyButton();

        Assert.assertTrue(login.isDashboardLoaded(role), role + " Dashboard not loaded");
    }
}
