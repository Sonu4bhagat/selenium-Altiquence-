package tests;

import base.BaseTest;
import helpers.MediaLibraryTestHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.MediaLibraryPage;

public class MediaLibraryTest extends BaseTest {
    MediaLibraryTestHelper helper;

    MediaLibraryPage mediaLibraryPage;
    @BeforeClass
    public void setupOnceForAllTests(){
        helper = new MediaLibraryTestHelper(driver);
        mediaLibraryPage = new MediaLibraryPage(driver);

        helper.loginAndNavigateToMediaLibrary();
    }

    @Test(priority = 1)
    public void testUploadMediaFileAndVerify() throws InterruptedException {
        mediaLibraryPage = new MediaLibraryPage(driver);
        mediaLibraryPage.navigateToAllFiles();
        mediaLibraryPage.clickUploadMedia();

        String fileToUpload = "demo-doc.pdf"; // Place this in resources/media/
        mediaLibraryPage.uploadMediaFile(fileToUpload);

        Thread.sleep(3000); // Replace with WebDriverWait if dynamic loading

        String uploadedFileName = mediaLibraryPage.getFirstMediaFileName();
        Assert.assertTrue(uploadedFileName.contains("demo-doc") || uploadedFileName.contains("demo"),
                "Uploaded file not found at the top of list");
    }
}
